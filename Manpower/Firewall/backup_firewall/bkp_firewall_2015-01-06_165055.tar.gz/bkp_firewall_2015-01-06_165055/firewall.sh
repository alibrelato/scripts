	#!/bin/bash
	echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
	echo "| Script de Firewall - IPTABLES					     |"
	echo "| Criado por: Paulo Ricardo kuhn				     |" 
	echo "| Seguranca da Informacao					     |"
	echo "| alphatec@shoppingbrasil.com.br		                     |"
	echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
	#####################################################################
	######################## VARIAVEIS DO SCRIPT ########################
 	#####################################################################
	IPTABLES=/usr/sbin/iptables
	MODPROBE=/sbin/modprobe
	SSH=60222
	LINKSB=201.22.213.230
	LINKCC=187.103.103.33
	INTSB=10.1.1.0/24
	INTCC=10.0.0.0/24
	VPN_ETH=tap0
	ANY=0.0.0.0/0
	##>>> Externa <<<###
	IF_LINK1=eth1
	IF_LINK1IP=177.159.101.197
	##>>> Interno <<<###
	IF_INT=eth0
	INT="192.168.0.0/24"
	##>>> Gateways do Link <<<###
	GW_LINK1='177.159.101.193'
	#####################################################################
	########################## FIREWALL SCRIPT ##########################
 	#####################################################################
	# Zera regras carregadas anteriormente ( "iptables --help | more" )
	iniciar()
    {
	##>>> Carrega os m�dulos <<<###
	modprobe ip_nat_ftp
	modprobe ip_conntrack_ftp
	modprobe ip_conntrack
	modprobe ip_tables
	modprobe iptable_nat
	modprobe iptable_nat	
	modprobe ipt_mac
	modprobe ipt_mark
	modprobe ipt_multiport
	modprobe ip_conntrack_ftp
	modprobe ip_nat_ftp
	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Inicio Firewall..........................." 
	echo "[ OK ]"
 	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Flush....................................."
	# Flush
	${IPTABLES} -F          
	${IPTABLES} -F -t nat
	${IPTABLES} -F -t mangle
	echo "[ OK ]"
	#
	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Ativando regras do Firewall..............."
	echo "[ OK ]"
	## >>> Definindo a Politica Default das Cadeias <<< ###
	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Default policies.........................."
	# Default policies
	${IPTABLES} -P INPUT DROP
	${IPTABLES} -P OUTPUT ACCEPT
	${IPTABLES} -P FORWARD DROP
	# Habilitando o trafego IP, entre as Interfaces de rede
	echo "1" > /proc/sys/net/ipv4/ip_forward
	echo "[ OK ]"
	### >>> Libera somente o necessario <<< ###
	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Conexoes estabelecidas...................."
	# Conexoes estabelecidas
	${IPTABLES} -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT	
	#${IPTABLES} -A OUTPUT -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT
	${IPTABLES} -A FORWARD -m state --state ESTABLISHED,RELATED,NEW -j ACCEPT
	#
	echo "[ OK ]"
	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Compartilhando a Internet................."
	${IPTABLES} -t nat -A POSTROUTING -o $IF_LINK1 -j MASQUERADE
	echo "[ OK ]"
	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Loopback.................................."
	# Loopback
	${IPTABLES} -A INPUT -i lo -j ACCEPT
	#${IPTABLES} -A OUTPUT -o lo -j ACCEPT
	echo "[ OK ]"
	#
	#------------------------------------------------------------------------------------------------------------
	#
	##>>> LIBERANDO SSH <<<###
	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Liberando acesso a SSH (OpenSSH) ........."
	# SSH
	${IPTABLES} -A INPUT -i $IF_LINK1 -p tcp --dport $SSH -j ACCEPT
	${IPTABLES} -A INPUT -i $IF_INT -p tcp --dport $SSH -j ACCEPT
	${IPTABLES} -A INPUT -i $VPN_ETH -p tcp --dport $SSH -j ACCEPT
	echo "[ OK ]"
	#
	#------------------------------------------------------------------------------------------------------------
	#
	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Servicos.................................."
	${IPTABLES} -A INPUT -f -j DROP
	${IPTABLES} -A INPUT -p tcp -s $ANY -d $ANY -m state --state INVALID -j DROP
	# Servicos no Firewall
	#Traceroute
	iptables -A INPUT -p udp --dport 33434 -j ACCEPT
	#iptables -A OUTPUT -p udp --dport 33434 -j ACCEPT
	iptables -A FORWARD -p udp --dport 33434 -j ACCEPT
	#
	# Libera consulta a DNS
	#${IPTABLES} -A INPUT -p udp -i $IF_INT --dport 53 -j ACCEPT
	#${IPTABLES} -t filter -A OUTPUT -p udp --dport 53 -j ACCEPT
	#${IPTABLES} -t filter -A FORWARD -i $IF_INT -p udp --dport 53 -j ACCEPT
	# Libera Ping para IP/Host especifico
	${IPTABLES} -A INPUT -s $INT -p icmp -j ACCEPT # Interna
	${IPTABLES} -A INPUT -s $LINKSB -p icmp -j ACCEPT # GVT_SB
	${IPTABLES} -A INPUT -s $LINKCC -p icmp -j ACCEPT # CC
	${IPTABLES} -A FORWARD -s $INT -p icmp -j ACCEPT # Interna
	${IPTABLES} -A FORWARD -s $INTSB -p icmp -j ACCEPT
	${IPTABLES} -A FORWARD -s $INTCC -p icmp -j ACCEPT
	${IPTABLES} -A OUTPUT -s $INT -p icmp -j ACCEPT # Interna
    ${IPTABLES} -A INPUT -s $INTSB -p icmp -j ACCEPT # SB
	${IPTABLES} -A INPUT -s $INTCC -p icmp -j ACCEPT # CC
	${IPTABLES} -A INPUT -s $INT -p icmp --icmp-type 8 -j ACCEPT
	iptables -A INPUT -p icmp -s $ANY --icmp-type 0 -m limit --limit 1/s -j ACCEPT
	iptables -A INPUT -p icmp -s $ANY --icmp-type 8 -m limit --limit 1/s -j ACCEPT
	iptables -A INPUT -p icmp -s $ANY --icmp-type 3 -m limit --limit 1/s -j ACCEPT
	iptables -A INPUT -p icmp -s $ANY --icmp-type 11 -m limit --limit 1/s -j ACCEPT
	echo "[ OK ]"
	#
	#------------------------------------------------------------------------------------------------------------
	#
	## >>> PROTE�OES <<< ###
	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Prote�oes................................."
	# Protecoes contra ataques
	${IPTABLES} -A INPUT -m state --state INVALID -j REJECT
	# Protege contra port scanners avan�ados (Ex.: nmap)
	${IPTABLES} -A FORWARD -p tcp --tcp-flags SYN,ACK,FIN,RST RST -m limit --limit 1/s -j ACCEPT
	${IPTABLES} -t filter -A INPUT -i $IF_LINK1 -m state --state new -j DROP
	#${IPTABLES} -N scan
	${IPTABLES} -A scan -j DROP
	${IPTABLES} -A INPUT -p tcp --tcp-flags ALL FIN,URG,PSH -i $IF_LINK1 -j scan
	${IPTABLES} -A INPUT -p tcp --tcp-flags ALL NONE -i $IF_LINK1 -j scan
	${IPTABLES} -A INPUT -p tcp --tcp-flags ALL ALL -i $IF_LINK1 -j scan
	${IPTABLES} -A INPUT -p tcp --tcp-flags ALL FIN,SYN -i $IF_LINK1 -j scan
	${IPTABLES} -A INPUT -p tcp --tcp-flags ALL SYN,RST,ACK,FIN,URG -i $IF_LINK1 -j scan
	${IPTABLES} -A INPUT -p tcp --tcp-flags SYN,RST SYN,RST -i $IF_LINK1 -j scan
	${IPTABLES} -A INPUT -p tcp --tcp-flags SYN,FIN SYN,FIN -i $IF_LINK1 -j scan
	for spoofing in /proc/sys/net/ipv4/conf/*/rp_filter; do
        echo "1" > $spoofing
	done
	# Bloqueio de scanners ocultos (Shealt Scan)
	${IPTABLES} -A FORWARD -p tcp --tcp-flags SYN,ACK, FIN,  -m limit --limit 1/s -j ACCEPT
	# Registro de logs
	${IPTABLES} -A INPUT -p tcp --dport 333 --syn -j LOG --log-prefix="[TENTATIVA ACESSO FWLOGWATCH]"
	${IPTABLES} -A INPUT -p tcp --dport 23 --syn -j LOG --log-prefix="[TENTATIVA ACESSO TELNET]"
	${IPTABLES} -A FORWARD -m multiport -p tcp --dport 5800,5900,6000 -j LOG --log-prefix="[ACESSO VNC]"
	${IPTABLES} -A INPUT -p tcp --dport $SSH --syn -j LOG --log-prefix="[TENTATIVA ACESSO SSH]"
	echo "[ OK ]"
	#
	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Liberacoes ..............................."
	# Bloquear tudo
	${IPTABLES} -A FORWARD -p tcp --destination-port 80 -s 192.168.0.9 -j ACCEPT
	#iptables -A FORWARD -s 192.168.0.9 -p tcp -m tcp --dport 80 -j ACCEPT
	echo "[ OK ]"
 	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Fim Firewall.............................."
	echo "[ OK ]"
	#------------------------------------------------------------------------------------------------------------
    }
    parar()
    {
	echo -n "[ $(date +%d/%m/%Y) $(date +%H:%M) ] Desativando Firewall......................"
	iptables -F -t nat
	echo "[ OK ]"
    }
    case "$1" in
    "start")
	iniciar
    ;;
    "stop")
	parar
    ;;
    "restart")
	parar;iniciar
    ;;
    *)
     echo "usar start, stop ou restart"
    esac
