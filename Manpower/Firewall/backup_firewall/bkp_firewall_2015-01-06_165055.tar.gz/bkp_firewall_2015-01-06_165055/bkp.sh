DATAHORA=`date +%Y-%m-%d_%H%M%S`
cd /etc/firewall/backup_firewall
mkdir bkp_firewall_$DATAHORA
cp ../*  bkp_firewall_$DATAHORA/
tar --file=bkp_firewall_$DATAHORA.tar.gz --exclude=*.tar.gz -cvz  bkp_firewall_$DATAHORA
rm -r bkp_firewall_$DATAHORA
