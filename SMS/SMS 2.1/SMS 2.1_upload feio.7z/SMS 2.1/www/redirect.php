<?php
header("Location: http://172.30.1.45/");
?>