<?php
//inicia a sessao
session_start();
//teste se a sessao eh valida, se vor invalida manda para a index
if($_SESSION[teste]!="666")
	{
    header("Location: index.html");
    exit;
    }
//se a sessao eh valida, apre o html abaixo com os botoes para fazer upload o arquivo
$sessao = $_SESSION[teste];     
?>
<html>
	<body>
		<form action="upload_file.php" method="POST" enctype="multipart/form-data">
			Upload de vouchers 
			<br><br>
			<input type="file" name="arquivo" size="20">
			<br>
			<input type="submit" value="Enviar">
		</form>
	</body>
</html>