<?php 

/*
Declaração das variaves de conexao com o AD via LDAP
*/
$us=$_POST['usuario'];
$pw=$_POST['senha'];
$server='172.30.1.57';
$admin='cn='.$us.',ou=DAL - Departamento de Assessoramento Legislativo,ou=SL - Superintendencia Legislativa,ou=Superintendencias,ou=ALRS,dc=alergs,dc=br';
$passwd=$pw;
$ds=ldap_connect($server);

// se o usuario nao foi preenchido retorna para o index
if (empty($us))
	{
	header("Location: index.html");
	}
// se a senha nao foi preenchido retorna para o index
else if (empty($pw))
	{
	header("Location: index.html");
	}
//se esta tudo certo entra na autenticacao
else
{
	//se esta conectado no LDAP
	if ($ds)
	{
		// faz a autenticacao e joga o resultado na variavel r
		$r=ldap_bind($ds, $admin, $passwd);
		// se a variavel r eh verdadeira
		if($r) 
		{
		// iniciamos uma sessao e redirecionamos para upload.php
		session_start();
     	$_SESSION["teste"] = "666";
		header("Location: upload.php");
		}
	//se nao conseguir autenticar o usuario, retorna para a index
	else
		{
		ldap_close($ds);
		header("Location: index.html");
		}
	}
}

?>
